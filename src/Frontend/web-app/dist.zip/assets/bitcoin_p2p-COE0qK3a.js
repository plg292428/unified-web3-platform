const s="/assets/bitcoin_p2p-Bh_d2XOH.svg";export{s as _};
